use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct Instruction {
    pub line_num: usize,
    pub text: String,
    pub address: usize,
}

/// 第一遍扫描：收集标签，返回符号表和指令列表
pub fn first_pass(source: &str) -> Result<(HashMap<String, usize>, Vec<Instruction>), String> {
    let mut symbols = HashMap::new();
    let mut instructions = Vec::new();
    let mut addr: usize = 0;

    for (line_num, raw_line) in source.lines().enumerate() {
        // 去掉注释
        let line = raw_line.split(';').next().unwrap_or("").trim();
        if line.is_empty() {
            continue;
        }

        // 标签定义（以 : 或 ： 结尾）
        if line.ends_with(':') || line.ends_with('：') {
            let label = &line[..line.len() - 1].trim();
            if label.is_empty() {
                return Err(format!("行 {}: 标签名为空", line_num + 1));
            }
            if symbols.contains_key(&label[..]) {
                return Err(format!("行 {}: 标签 '{}' 重复定义", line_num + 1, label));
            }
            symbols.insert(label.to_string(), addr);
        } else {
            instructions.push(Instruction {
                line_num: line_num + 1,
                text: line.to_string(),
                address: addr,
            });
            addr += 1;
        }
    }

    Ok((symbols, instructions))
}

/// 将指令文本解析为 token 列表
pub fn tokenize(line: &str) -> Vec<String> {
    let mut tokens = Vec::new();
    let mut current = String::new();

    for ch in line.chars() {
        if ch == ',' || ch == ' ' || ch == '\t' {
            if !current.is_empty() {
                tokens.push(current.clone());
                current.clear();
            }
        } else {
            current.push(ch);
        }
    }
    if !current.is_empty() {
        tokens.push(current);
    }

    tokens
}
