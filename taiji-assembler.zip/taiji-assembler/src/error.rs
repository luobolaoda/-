use std::fmt;

#[derive(Debug)]
pub enum Error {
    Parse(String),
    Encode(String),
    Io(std::io::Error),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Parse(msg) => write!(f, "解析错误: {}", msg),
            Error::Encode(msg) => write!(f, "编码错误: {}", msg),
            Error::Io(e) => write!(f, "IO错误: {}", e),
        }
    }
}

impl std::error::Error for Error {}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e)
    }
}

impl From<String> for Error {
    fn from(s: String) -> Self {
        Error::Parse(s)
    }
}
