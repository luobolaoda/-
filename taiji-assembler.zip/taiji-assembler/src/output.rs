use crate::trit::Trit;
use crate::word::Word;
use crate::decoder::{DecodeEntry, Polarity};
use crate::parser::Instruction;
use std::fs::File;
use std::io::Write;

/// 写入 .tjbin 机器码文件
pub fn write_binary(path: &str, machine_code: &[Word]) -> Result<(), String> {
    let mut file = File::create(path).map_err(|e| format!("无法创建文件 {}: {}", path, e))?;

    for word in machine_code {
        let line = word.to_string();
        writeln!(file, "{}", line).map_err(|e| format!("写入失败: {}", e))?;
    }

    Ok(())
}

/// 写入 .tjlst 列表文件
pub fn write_listing(
    path: &str,
    instructions: &[Instruction],
    machine_code: &[Word],
    decoder: &crate::decoder::Decoder,
) -> Result<(), String> {
    let mut file = File::create(path).map_err(|e| format!("无法创建文件 {}: {}", path, e))?;

    for (i, inst) in instructions.iter().enumerate() {
        let tokens = crate::parser::tokenize(&inst.text);
        let mnemonic = &tokens[0];

        let polarity_str = if let Some(entry) = decoder.decode(mnemonic) {
            match entry.polarity {
                Polarity::Yang => "[阳]",
                Polarity::Taiji => "[太极]",
                Polarity::Yin => "[阴]",
            }
        } else {
            "[?]"
        };

        let mc_str = if i < machine_code.len() {
            machine_code[i].to_string()
        } else {
            "???".to_string()
        };

        writeln!(
            file,
            "{:<6}  {}  {:<6}  {}",
            inst.address, mc_str, polarity_str, inst.text
        )
        .map_err(|e| format!("写入失败: {}", e))?;
    }

    Ok(())
}

pub fn polarity_str(polarity: Polarity) -> &'static str {
    match polarity {
        Polarity::Yang => "[阳]",
        Polarity::Taiji => "[太极]",
        Polarity::Yin => "[阴]",
    }
}
