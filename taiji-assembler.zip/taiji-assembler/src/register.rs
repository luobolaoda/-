use crate::trit::Trit;
use std::collections::HashMap;

pub struct RegisterTable {
    table: HashMap<String, [Trit; 3]>,
}

impl RegisterTable {
    pub fn new() -> Self {
        let mut table = HashMap::new();
        let y = Trit::Yin;
        let t = Trit::Taiji;
        let a = Trit::Yang;

        table.insert("返零".into(), [y, y, y]);
        table.insert("返一".into(), [y, y, t]);
        table.insert("参一".into(), [y, y, a]);
        table.insert("参二".into(), [y, t, y]);
        table.insert("参三".into(), [y, t, t]);
        table.insert("参四".into(), [y, t, a]);
        table.insert("临一".into(), [y, a, y]);
        table.insert("临二".into(), [y, a, t]);
        table.insert("临三".into(), [y, a, a]);
        table.insert("临四".into(), [t, y, y]);
        table.insert("临五".into(), [t, y, t]);
        table.insert("临六".into(), [t, y, a]);
        table.insert("临七".into(), [t, t, y]);
        table.insert("临八".into(), [t, t, t]);
        table.insert("临九".into(), [t, t, a]);
        table.insert("保一".into(), [t, a, y]);
        table.insert("保二".into(), [t, a, t]);
        table.insert("保三".into(), [t, a, a]);
        table.insert("栈针".into(), [a, y, y]);
        table.insert("帧针".into(), [a, y, t]);
        table.insert("链存".into(), [a, y, a]);
        table.insert("循计".into(), [a, t, y]);
        table.insert("状存".into(), [a, t, t]);
        table.insert("异因".into(), [a, t, a]);
        table.insert("程计".into(), [a, a, y]);
        table.insert("零存".into(), [a, a, t]);
        table.insert("一存".into(), [a, a, a]);

        RegisterTable { table }
    }

    pub fn lookup(&self, name: &str) -> Option<[Trit; 3]> {
        self.table.get(name).copied()
    }
}
