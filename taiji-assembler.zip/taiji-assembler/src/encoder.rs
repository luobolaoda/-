use crate::trit::Trit;

/// 将 i64 编码为 N trit 的平衡三进制（低位在前）
pub fn encode_int(value: i64, width: usize) -> Result<Vec<Trit>, String> {
    let mut result = vec![Trit::Taiji; width];
    let mut n = value;
    let mut i = 0;

    while n != 0 && i < width {
        let mut rem = n % 3;
        if rem < 0 {
            rem += 3;
        }
        match rem {
            0 => {
                result[i] = Trit::Taiji;
            }
            1 => {
                result[i] = Trit::Yang;
                n -= 1;
            }
            2 => {
                result[i] = Trit::Yin;
                n += 1;
            }
            _ => unreachable!(),
        }
        n /= 3;
        i += 1;
    }

    if n != 0 {
        return Err(format!("立即数 {} 超出 {} trit 范围", value, width));
    }

    Ok(result)
}

/// 解析立即数字符串
pub fn parse_immediate(token: &str, symbols: &std::collections::HashMap<String, usize>, current_addr: usize) -> Result<i64, String> {
    let token = token.strip_prefix('#').unwrap_or(token);

    match token {
        "阴" => Ok(-1),
        "太极" => Ok(0),
        "阳" => Ok(1),
        _ => {
            // 尝试作为标签引用
            if let Some(&addr) = symbols.get(token) {
                return Ok(addr as i64);
            }
            // 尝试作为十进制数字
            token.parse::<i64>()
                .map_err(|_| format!("无法解析立即数: '{}'", token))
        }
    }
}
