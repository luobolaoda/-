mod trit;
mod word;
mod decoder;
mod register;
mod parser;
mod encoder;
mod output;
mod error;

use trit::Trit;
use word::Word;
use decoder::{Decoder, OpShape, Polarity};
use register::RegisterTable;
use std::collections::HashMap;

fn main() -> Result<(), String> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        eprintln!("用法: taiji-asm <源文件.taiji>");
        eprintln!("示例: taiji-asm hello.taiji");
        return Ok(());
    }

    let input_path = &args[1];
    let source = std::fs::read_to_string(input_path)
        .map_err(|e| format!("无法读取文件 {}: {}", input_path, e))?;

    let decoder = Decoder::new();
    let registers = RegisterTable::new();

    // 第一遍：收集标签
    let (symbols, instructions) = parser::first_pass(&source)?;
    println!("第一遍扫描完成: {} 个标签, {} 条指令", symbols.len(), instructions.len());

    // 第二遍：生成机器码
    let machine_code = second_pass(&instructions, &symbols, &decoder, &registers)?;
    println!("第二遍扫描完成: {} 极字机器码", machine_code.len());

    // 输出 .tjbin
    let bin_path = input_path.replace(".taiji", ".tjbin");
    output::write_binary(&bin_path, &machine_code)?;
    println!("机器码文件: {}", bin_path);

    // 输出 .tjlst
    let lst_path = input_path.replace(".taiji", ".tjlst");
    output::write_listing(&lst_path, &instructions, &machine_code, &decoder)?;
    println!("列表文件: {}", lst_path);

    println!("汇编完成。");
    Ok(())
}

fn second_pass(
    instructions: &[parser::Instruction],
    symbols: &HashMap<String, usize>,
    decoder: &Decoder,
    registers: &RegisterTable,
) -> Result<Vec<Word>, String> {
    let mut machine_code = Vec::new();

    for inst in instructions {
        let tokens = parser::tokenize(&inst.text);
        if tokens.is_empty() {
            return Err(format!("行 {}: 空指令", inst.line_num));
        }

        let mnemonic = &tokens[0];
        let entry = decoder
            .decode(mnemonic)
            .ok_or_else(|| format!("行 {}: 未知指令 '{}'", inst.line_num, mnemonic))?;

        let word = match entry.shape {
            OpShape::TriForm => encode_tri_form(inst, &tokens, entry, registers)?,
            OpShape::LiForm => encode_li_form(inst, &tokens, entry, registers, symbols)?,
            OpShape::YueForm => encode_yue_form(inst, &tokens, entry, symbols)?,
        };

        machine_code.push(word);
    }

    Ok(machine_code)
}

/// 编码三合形：操作码(4) + rd(3) + rs1(3) + rs2(3) + 功能码(14，功能码隐含为全太极)
/// 支持 3 参数 (rd, rs1, rs2) 或 0 参数 (如停机)
fn encode_tri_form(
    inst: &parser::Instruction,
    tokens: &[String],
    entry: &decoder::DecodeEntry,
    registers: &RegisterTable,
) -> Result<Word, String> {
    // 无操作数指令（如停机）
    if tokens.len() == 1 {
        let mut word = Word::new_zero();
        word.set_high(23, &entry.opcode);
        return Ok(word);
    }
    
    if tokens.len() < 4 {
        return Err(format!("行 {}: 三合形指令需要 0 或 3 个操作数(rd, rs1, rs2)，实际 {}", inst.line_num, tokens.len() - 1));
    }

    let rd = registers
        .lookup(&tokens[1])
        .ok_or_else(|| format!("行 {}: 未知寄存器 '{}'", inst.line_num, tokens[1]))?;
    let rs1 = registers
        .lookup(&tokens[2])
        .ok_or_else(|| format!("行 {}: 未知寄存器 '{}'", inst.line_num, tokens[2]))?;
    let rs2 = registers
        .lookup(&tokens[3])
        .ok_or_else(|| format!("行 {}: 未知寄存器 '{}'", inst.line_num, tokens[3]))?;

    let mut word = Word::new_zero();
    // 操作码：trit 23..26（即 word.trits[23..27]）
    word.set_high(23, &entry.opcode);
    // rd：trit 20..22
    word.set_high(20, &rd);
    // rs1：trit 17..19
    word.set_high(17, &rs1);
    // rs2：trit 14..16
    word.set_high(14, &rs2);
    // 功能码：trit 0..13，全太极
    Ok(word)
}

/// 编码立合形：操作码(4) + rd(3) + rs1(3) + 立即数(17)
/// 支持 3 参数 (rd, rs1, imm) 或 2 参数 (rd, imm，rs1 默认为零寄存器)
fn encode_li_form(
    inst: &parser::Instruction,
    tokens: &[String],
    entry: &decoder::DecodeEntry,
    registers: &RegisterTable,
    symbols: &HashMap<String, usize>,
) -> Result<Word, String> {
    if tokens.len() < 3 {
        return Err(format!("行 {}: 立合形指令需要 2-3 个操作数(rd, [rs1], 立即数)，实际 {}", inst.line_num, tokens.len() - 1));
    }

    let rd = registers
        .lookup(&tokens[1])
        .ok_or_else(|| format!("行 {}: 未知寄存器 '{}'", inst.line_num, tokens[1]))?;

    // rs1 默认为零寄存器 (零)
    let rs1 = if tokens.len() >= 4 {
        registers
            .lookup(&tokens[2])
            .ok_or_else(|| format!("行 {}: 未知寄存器 '{}'", inst.line_num, tokens[2]))?
    } else {
        [Trit::Taiji, Trit::Taiji, Trit::Taiji]  // 零寄存器
    };

    let imm_value = if tokens.len() >= 4 {
        encoder::parse_immediate(&tokens[3], symbols, inst.address)?
    } else {
        encoder::parse_immediate(&tokens[2], symbols, inst.address)?
    };
    let imm_trits = encoder::encode_int(imm_value, 17)?;

    let mut word = Word::new_zero();
    word.set_high(23, &entry.opcode);
    word.set_high(20, &rd);
    word.set_high(17, &rs1);
    // 立即数：trit 0..16
    word.set_high(16, &imm_trits);
    Ok(word)
}

/// 编码跃合形：操作码(4) + 偏移(23)
fn encode_yue_form(
    inst: &parser::Instruction,
    tokens: &[String],
    entry: &decoder::DecodeEntry,
    symbols: &HashMap<String, usize>,
) -> Result<Word, String> {
    if tokens.len() < 2 {
        return Err(format!("行 {}: 跃合形指令需要一个目标标签", inst.line_num));
    }

    let target_addr = symbols
        .get(&tokens[1])
        .ok_or_else(|| format!("行 {}: 未定义标签 '{}'", inst.line_num, tokens[1]))?;

    // 偏移 = 目标地址 - (当前地址 + 1)
    let offset = *target_addr as i64 - (inst.address as i64 + 1);
    let offset_trits = encoder::encode_int(offset, 23)?;

    let mut word = Word::new_zero();
    word.set_high(23, &entry.opcode);
    word.set_high(22, &offset_trits);
    Ok(word)
}
