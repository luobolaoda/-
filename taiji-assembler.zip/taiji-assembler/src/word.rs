use crate::trit::Trit;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Word {
    pub trits: [Trit; 27],
}

impl Word {
    pub fn new_zero() -> Self {
        Word {
            trits: [Trit::Taiji; 27],
        }
    }

    /// 从低位到高位填入 trit，高位补太极
    pub fn from_trits_lsb(trits: &[Trit]) -> Self {
        let mut word = Word::new_zero();
        let len = trits.len().min(27);
        for i in 0..len {
            word.trits[26 - i] = trits[len - 1 - i];
        }
        word
    }

    /// 设置高位的连续 trit（用于操作码放在高位的场景）
    pub fn set_high(&mut self, start: usize, trits: &[Trit]) {
        for i in 0..trits.len() {
            if start + i < 27 {
                self.trits[start + i] = trits[i];
            }
        }
    }

    /// 设置从某个位置开始的 trit（最高位为索引 26）
    pub fn set_from_msb(&mut self, msb_offset: usize, trits: &[Trit]) {
        let start = 26 - msb_offset;
        for i in 0..trits.len() {
            if start >= i {
                self.trits[start - i] = trits[trits.len() - 1 - i];
            }
        }
    }

    pub fn to_string(&self) -> String {
        self.trits.iter().map(|t| t.to_char()).collect()
    }
}
