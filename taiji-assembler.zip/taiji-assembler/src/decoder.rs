use crate::trit::Trit;
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Polarity {
    Yang,
    Taiji,
    Yin,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OpShape {
    TriForm,
    LiForm,
    YueForm,
}

#[derive(Debug, Clone)]
pub struct DecodeEntry {
    pub opcode: [Trit; 4],
    pub polarity: Polarity,
    pub shape: OpShape,
    pub mnemonic: String,
}

pub struct Decoder {
    table: HashMap<String, DecodeEntry>,
}

impl Decoder {
    pub fn new() -> Self {
        let mut table = HashMap::new();

        // === 阳指令 (10条) ===
        table.insert("停机".into(), entry("++++", Polarity::Yang, OpShape::TriForm, "停机"));
        table.insert("调用".into(), entry("+++0", Polarity::Yang, OpShape::YueForm, "调用"));
        table.insert("返回".into(), entry("+++-", Polarity::Yang, OpShape::TriForm, "返回"));
        table.insert("跳转".into(), entry("++00", Polarity::Yang, OpShape::YueForm, "跳转"));
        table.insert("压栈".into(), entry("++0-", Polarity::Yang, OpShape::LiForm, "压栈"));
        table.insert("存入".into(), entry("++-0", Polarity::Yang, OpShape::LiForm, "存入"));
        table.insert("输出".into(), entry("+0++", Polarity::Yang, OpShape::LiForm, "输出"));
        table.insert("分配".into(), entry("+-++", Polarity::Yang, OpShape::LiForm, "分配"));
        table.insert("输入".into(), entry("+0+-", Polarity::Yang, OpShape::LiForm, "输入"));
        table.insert("等跳".into(), entry("+-+0", Polarity::Yang, OpShape::LiForm, "等跳"));

        // === 太极指令 (19条) ===
        table.insert("加法".into(), entry("++--", Polarity::Taiji, OpShape::TriForm, "加法"));
        table.insert("减法".into(), entry("+-+-", Polarity::Taiji, OpShape::TriForm, "减法"));
        table.insert("乘法".into(), entry("+--+", Polarity::Taiji, OpShape::TriForm, "乘法"));
        table.insert("除法".into(), entry("-++-", Polarity::Taiji, OpShape::TriForm, "除法"));
        table.insert("与".into(),   entry("-+-+", Polarity::Taiji, OpShape::TriForm, "与"));
        table.insert("或".into(),   entry("--++", Polarity::Taiji, OpShape::TriForm, "或"));
        table.insert("异或".into(), entry("+-00", Polarity::Taiji, OpShape::TriForm, "异或"));
        table.insert("非".into(),   entry("+0-0", Polarity::Taiji, OpShape::TriForm, "非"));
        table.insert("左移".into(), entry("+00-", Polarity::Taiji, OpShape::TriForm, "左移"));
        table.insert("右移".into(), entry("-+00", Polarity::Taiji, OpShape::TriForm, "右移"));
        table.insert("传送".into(), entry("-0+0", Polarity::Taiji, OpShape::LiForm, "传送"));
        table.insert("比较".into(), entry("-00+", Polarity::Taiji, OpShape::TriForm, "比较"));
        table.insert("同步".into(), entry("0+-0", Polarity::Taiji, OpShape::TriForm, "同步"));
        table.insert("屏障".into(), entry("0-+0", Polarity::Taiji, OpShape::TriForm, "屏障"));
        table.insert("原子操".into(), entry("0+0-", Polarity::Taiji, OpShape::TriForm, "原子操"));
        table.insert("协程".into(), entry("0-0+", Polarity::Taiji, OpShape::TriForm, "协程"));
        table.insert("浮加".into(), entry("00+-", Polarity::Taiji, OpShape::TriForm, "浮加"));
        table.insert("浮乘".into(), entry("00-+", Polarity::Taiji, OpShape::TriForm, "浮乘"));
        table.insert("空转".into(), entry("0000", Polarity::Taiji, OpShape::TriForm, "空转"));

        // === 阴指令 (16条) ===
        table.insert("释放".into(), entry("----", Polarity::Yin, OpShape::LiForm, "释放"));
        table.insert("出栈".into(), entry("---0", Polarity::Yin, OpShape::TriForm, "出栈"));
        table.insert("逆执".into(), entry("--0-", Polarity::Yin, OpShape::TriForm, "逆执"));
        table.insert("降能级".into(), entry("-0--", Polarity::Yin, OpShape::LiForm, "降能级"));
        table.insert("刷新".into(), entry("0---", Polarity::Yin, OpShape::TriForm, "刷新"));
        table.insert("批量回收".into(), entry("--+0", Polarity::Yin, OpShape::TriForm, "批量回收"));
        table.insert("加载".into(), entry("--0+", Polarity::Yin, OpShape::LiForm, "加载"));
        table.insert("极性".into(), entry("-+--", Polarity::Yin, OpShape::TriForm, "极性"));
        table.insert("循环左".into(), entry("-+-0", Polarity::Yin, OpShape::TriForm, "循环左"));
        table.insert("循环右".into(), entry("-+0-", Polarity::Yin, OpShape::TriForm, "循环右"));
        table.insert("不等于跳".into(), entry("-0-+", Polarity::Yin, OpShape::LiForm, "不等于跳"));
        table.insert("小于跳".into(), entry("+---", Polarity::Yin, OpShape::LiForm, "小于跳"));
        table.insert("大于跳".into(), entry("+--0", Polarity::Yin, OpShape::LiForm, "大于跳"));
        table.insert("栅栏全".into(), entry("+-0-", Polarity::Yin, OpShape::TriForm, "栅栏全"));
        table.insert("栅栏存".into(), entry("+0--", Polarity::Yin, OpShape::TriForm, "栅栏存"));
        table.insert("验证".into(), entry("0--+", Polarity::Yin, OpShape::TriForm, "验证"));

        Decoder { table }
    }

    pub fn decode(&self, mnemonic: &str) -> Option<&DecodeEntry> {
        self.table.get(mnemonic)
    }

    pub fn all_mnemonics(&self) -> Vec<&String> {
        self.table.keys().collect()
    }
}

fn entry(op_str: &str, polarity: Polarity, shape: OpShape, mnemonic: &str) -> DecodeEntry {
    let chars: Vec<char> = op_str.chars().collect();
    let mut opcode = [Trit::Taiji; 4];
    for i in 0..chars.len().min(4) {
        opcode[i] = Trit::from_char(chars[i]).unwrap();
    }
    DecodeEntry {
        opcode,
        polarity,
        shape,
        mnemonic: mnemonic.to_string(),
    }
}
