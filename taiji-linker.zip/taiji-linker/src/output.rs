use crate::trit::Trit;
use crate::symbol::SymbolTable;
use std::fs::File;
use std::io::Write;

pub fn write_exe(
    path: &str,
    entry: usize,
    code: &[Vec<Trit>],
    data: &[Vec<Trit>],
    bss_size: usize,
    const_data: &[Vec<Trit>],
    stack_size: usize,
    symtab: &SymbolTable,
) -> Result<(), String> {
    let mut file = File::create(path).map_err(|e| format!("无法创建文件 {}: {}", path, e))?;

    // 文件头
    writeln!(file, "# tjexe v1.0").map_err(|e| e.to_string())?;
    writeln!(file, "entry 0x{:X}", entry).map_err(|e| e.to_string())?;
    writeln!(file, "code_size {}", code.len()).map_err(|e| e.to_string())?;
    writeln!(file, "data_size {}", data.len()).map_err(|e| e.to_string())?;
    writeln!(file, "bss_size {}", bss_size).map_err(|e| e.to_string())?;
    writeln!(file, "const_size {}", const_data.len()).map_err(|e| e.to_string())?;
    writeln!(file, "stack_size {}", stack_size).map_err(|e| e.to_string())?;

    // 符号表
    writeln!(file, "symbols {}", symtab.len()).map_err(|e| e.to_string())?;
    for (name, addr) in symtab.iter() {
        writeln!(file, "{} 0x{:X}", name, addr).map_err(|e| e.to_string())?;
    }

    // 代码段
    writeln!(file, ".section \".text\"").map_err(|e| e.to_string())?;
    for word in code {
        let line: String = word.iter().map(|t| t.to_char()).collect();
        writeln!(file, "{}", line).map_err(|e| e.to_string())?;
    }

    // 数据段
    writeln!(file, ".section \".data\"").map_err(|e| e.to_string())?;
    for word in data {
        let line: String = word.iter().map(|t| t.to_char()).collect();
        writeln!(file, "{}", line).map_err(|e| e.to_string())?;
    }

    // 常量段
    writeln!(file, ".section \".const\"").map_err(|e| e.to_string())?;
    for word in const_data {
        let line: String = word.iter().map(|t| t.to_char()).collect();
        writeln!(file, "{}", line).map_err(|e| e.to_string())?;
    }

    Ok(())
}
