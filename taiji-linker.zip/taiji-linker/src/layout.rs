pub struct MemoryLayout {
    pub code_start: usize,
    pub data_start: usize,
    pub const_start: usize,
    pub stack_top: usize,
}

impl Default for MemoryLayout {
    fn default() -> Self {
        MemoryLayout {
            code_start: 0x0000100,
            data_start: 0x1000000,
            const_start: 0x8000000,
            stack_top: 0x7FFFFFF,
        }
    }
}
