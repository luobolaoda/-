use std::collections::HashMap;

pub struct SymbolTable {
    symbols: HashMap<String, usize>,
}

impl SymbolTable {
    pub fn new() -> Self {
        SymbolTable {
            symbols: HashMap::new(),
        }
    }

    pub fn add(&mut self, name: &str, addr: usize) -> Result<(), String> {
        if self.symbols.contains_key(name) {
            return Err(format!("符号 '{}' 重复定义", name));
        }
        self.symbols.insert(name.to_string(), addr);
        Ok(())
    }

    pub fn get(&self, name: &str) -> Option<usize> {
        self.symbols.get(name).copied()
    }

    pub fn len(&self) -> usize {
        self.symbols.len()
    }

    pub fn iter(&self) -> impl Iterator<Item = (&String, &usize)> {
        self.symbols.iter()
    }
}
