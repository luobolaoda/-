mod trit;
mod object;
mod symbol;
mod layout;
mod output;

pub use trit::Trit;
pub use object::ObjectFile;
pub use symbol::SymbolTable;
pub use layout::MemoryLayout;

fn main() -> Result<(), String> {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 3 {
        eprintln!("用法: taiji-ld <输出文件.tjexe> <输入文件1.tjo> [输入文件2.tjo ...]");
        eprintln!("示例: taiji-ld 程序.tjexe 主函数.tjo 工具.tjo");
        return Ok(());
    }

    let output_path = &args[1];
    let input_paths: Vec<&str> = args[2..].iter().map(|s| s.as_str()).collect();

    if input_paths.is_empty() {
        return Err("没有输入文件".into());
    }

    println!("太极链接器 v1.0");
    println!("输出文件: {}", output_path);
    println!("输入文件: {:?}", input_paths);

    // 1. 读取所有目标文件
    let mut objects = Vec::new();
    for path in &input_paths {
        println!("  加载: {}", path);
        let source = std::fs::read_to_string(path)
            .map_err(|e| format!("无法读取文件 {}: {}", path, e))?;
        let obj = ObjectFile::parse(&source, path)?;
        objects.push(obj);
    }

    // 2. 合并段
    let mut code_segment = Vec::new();
    let mut data_segment = Vec::new();
    let mut bss_size: usize = 0;
    let mut const_segment = Vec::new();

    // 记录每个目标文件中各段在合并后的偏移
    let mut section_offsets: Vec<SectionOffsets> = Vec::new();

    for obj in &objects {
        let mut offsets = SectionOffsets::default();

        if !obj.code.is_empty() {
            offsets.code_start = code_segment.len();
            offsets.code_size = obj.code.len();
            code_segment.extend_from_slice(&obj.code);
        }

        if !obj.data.is_empty() {
            offsets.data_start = data_segment.len();
            offsets.data_size = obj.data.len();
            data_segment.extend_from_slice(&obj.data);
        }

        if obj.bss_size > 0 {
            offsets.bss_start = bss_size;
            offsets.bss_size = obj.bss_size;
            bss_size += obj.bss_size;
        }

        if !obj.const_data.is_empty() {
            offsets.const_start = const_segment.len();
            offsets.const_size = obj.const_data.len();
            const_segment.extend_from_slice(&obj.const_data);
        }

        section_offsets.push(offsets);
    }

    println!("  代码段: {} 极字", code_segment.len());
    println!("  数据段: {} 极字", data_segment.len());
    println!("  BSS段:  {} 极字", bss_size);
    println!("  常量段: {} 极字", const_segment.len());

    // 3. 分配地址
    let layout = MemoryLayout::default();
    let code_base = layout.code_start;
    let data_base = layout.data_start;
    let const_base = layout.const_start;

    // 4. 收集全局符号
    let mut symtab = SymbolTable::new();
    for (i, obj) in objects.iter().enumerate() {
        let offsets = &section_offsets[i];
        for sym in &obj.symbols {
            if sym.is_global() && !sym.is_undefined() {
                let final_addr = match sym.section.as_str() {
                    ".text" => code_base + offsets.code_start + sym.value,
                    ".data" => data_base + offsets.data_start + sym.value,
                    ".bss" => data_base + data_segment.len() + offsets.bss_start + sym.value,
                    ".const" => const_base + offsets.const_start + sym.value,
                    _ => continue,
                };
                symtab.add(&sym.name, final_addr)?;
            }
        }
    }

    println!("  全局符号: {} 个", symtab.len());

    // 5. 执行重定位
    for (i, obj) in objects.iter().enumerate() {
        let offsets = &section_offsets[i];
        for reloc in &obj.relocations {
            let sym_addr = symtab
                .get(&reloc.symbol_name)
                .ok_or_else(|| format!("未定义的外部符号: '{}'", reloc.symbol_name))?;

            let (section_data, section_base) = match reloc.section.as_str() {
                ".text" => (&mut code_segment, code_base + offsets.code_start),
                ".data" => (&mut data_segment, data_base + offsets.data_start),
                _ => return Err(format!("不支持的重定位段: '{}'", reloc.section)),
            };

            let patch_addr = reloc.offset;

            match reloc.kind {
                RelocKind::Absolute => {
                    let value = (sym_addr as i64 + reloc.addend) as usize;
                    patch_word(section_data, patch_addr, value);
                }
                RelocKind::Relative => {
                    let target_addr = section_base + patch_addr;
                    let offset = sym_addr as i64 - (target_addr as i64 + 1);
                    patch_word_signed(section_data, patch_addr, offset);
                }
            }
        }
    }

    println!("  重定位完成");

    // 6. 确定入口地址
    let entry = symtab
        .get("_start")
        .unwrap_or(code_base);

    // 7. 写入可执行文件
    output::write_exe(
        output_path,
        entry,
        &code_segment,
        &data_segment,
        bss_size,
        &const_segment,
        65536, // 默认栈大小
        &symtab,
    )?;

    println!("  入口地址: 0x{:X}", entry);
    println!("链接完成: {}", output_path);
    Ok(())
}

#[derive(Debug, Default)]
struct SectionOffsets {
    code_start: usize,
    code_size: usize,
    data_start: usize,
    data_size: usize,
    bss_start: usize,
    bss_size: usize,
    const_start: usize,
    const_size: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RelocKind {
    Absolute,
    Relative,
}

fn patch_word(segment: &mut Vec<Vec<Trit>>, offset: usize, value: usize) {
    if offset < segment.len() {
        let word = encode_usize_to_word(value);
        segment[offset] = word;
    }
}

fn patch_word_signed(segment: &mut Vec<Vec<Trit>>, offset: usize, value: i64) {
    if offset < segment.len() {
        let word = encode_i64_to_word(value, 27);
        segment[offset] = word;
    }
}

fn encode_usize_to_word(value: usize) -> Vec<Trit> {
    encode_i64_to_word(value as i64, 27)
}

fn encode_i64_to_word(mut value: i64, width: usize) -> Vec<Trit> {
    let mut result = vec![Trit::Taiji; width];
    let mut i = 0;
    while value != 0 && i < width {
        let mut rem = value % 3;
        if rem < 0 {
            rem += 3;
        }
        match rem {
            0 => {
                result[i] = Trit::Taiji;
            }
            1 => {
                result[i] = Trit::Yang;
                value -= 1;
            }
            2 => {
                result[i] = Trit::Yin;
                value += 1;
            }
            _ => unreachable!(),
        }
        value /= 3;
        i += 1;
    }
    result
}
