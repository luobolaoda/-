use crate::trit::Trit;

#[derive(Debug, Clone)]
pub struct Symbol {
    pub name: String,
    pub value: usize,
    pub section: String,
    pub is_global: bool,
    pub is_undefined: bool,
}

impl Symbol {
    pub fn is_global(&self) -> bool {
        self.is_global
    }

    pub fn is_undefined(&self) -> bool {
        self.is_undefined
    }
}

#[derive(Debug, Clone)]
pub struct Relocation {
    pub offset: usize,
    pub section: String,
    pub symbol_name: String,
    pub kind: crate::RelocKind,
    pub addend: i64,
}

#[derive(Debug)]
pub struct ObjectFile {
    pub code: Vec<Vec<Trit>>,
    pub data: Vec<Vec<Trit>>,
    pub bss_size: usize,
    pub const_data: Vec<Vec<Trit>>,
    pub symbols: Vec<Symbol>,
    pub relocations: Vec<Relocation>,
}

impl ObjectFile {
    pub fn parse(source: &str, filepath: &str) -> Result<Self, String> {
        let mut code = Vec::new();
        let mut data = Vec::new();
        let mut bss_size = 0;
        let mut const_data = Vec::new();
        let mut symbols = Vec::new();
        let mut relocations = Vec::new();

        let mut current_section = "";

        for (line_num, raw_line) in source.lines().enumerate() {
            let line = raw_line.trim();
            if line.is_empty() || line.starts_with('#') {
                continue;
            }

            if line.starts_with(".section ") {
                current_section = line[9..].trim().trim_matches('"');
                continue;
            }

            if line.starts_with(".sym ") {
                let parts: Vec<&str> = line[5..].split_whitespace().collect();
                if parts.len() >= 3 {
                    let name = parts[0].to_string();
                    let value = parts[1].parse::<usize>().unwrap_or(0);
                    let section = parts[2].to_string();
                    let is_global = parts.len() > 3 && parts[3] == "global";
                    let is_undefined = parts.len() > 4 && parts[4] == "undef";

                    symbols.push(Symbol {
                        name,
                        value,
                        section,
                        is_global,
                        is_undefined,
                    });
                }
                continue;
            }

            if line.starts_with(".reloc ") {
                let parts: Vec<&str> = line[7..].split_whitespace().collect();
                if parts.len() >= 4 {
                    let offset = parts[0].parse::<usize>().unwrap_or(0);
                    let section = parts[1].to_string();
                    let symbol_name = parts[2].to_string();
                    let kind = match parts[3] {
                        "abs" => crate::RelocKind::Absolute,
                        "rel" => crate::RelocKind::Relative,
                        _ => return Err(format!("{}:{}: 未知的重定位类型 '{}'", filepath, line_num + 1, parts[3])),
                    };
                    let addend = parts.get(4).and_then(|s| s.parse::<i64>().ok()).unwrap_or(0);

                    relocations.push(Relocation {
                        offset,
                        section,
                        symbol_name,
                        kind,
                        addend,
                    });
                }
                continue;
            }

            if line.starts_with(".bss ") {
                let parts: Vec<&str> = line[5..].split_whitespace().collect();
                if !parts.is_empty() {
                    bss_size = parts[0].parse::<usize>().unwrap_or(0);
                }
                continue;
            }

            // 数据行：极字序列（+/-/0 组成的字符串）
            let word: Vec<Trit> = line
                .chars()
                .filter(|c| *c == '+' || *c == '-' || *c == '0')
                .map(|c| Trit::from_char(c).unwrap())
                .collect();

            if !word.is_empty() {
                match current_section {
                    ".text" => code.push(word),
                    ".data" => data.push(word),
                    ".const" => const_data.push(word),
                    _ => {}
                }
            }
        }

        Ok(ObjectFile {
            code,
            data,
            bss_size,
            const_data,
            symbols,
            relocations,
        })
    }
}
