use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Trit {
    Yin = -1,
    Taiji = 0,
    Yang = 1,
}

impl Trit {
    pub fn to_char(self) -> char {
        match self {
            Trit::Yin => '-',
            Trit::Taiji => '0',
            Trit::Yang => '+',
        }
    }

    pub fn from_char(c: char) -> Result<Self, String> {
        match c {
            '-' => Ok(Trit::Yin),
            '0' => Ok(Trit::Taiji),
            '+' => Ok(Trit::Yang),
            _ => Err(format!("无效的极位字符: '{}'", c)),
        }
    }

    pub fn to_i8(self) -> i8 {
        self as i8
    }

    pub fn from_i8(n: i8) -> Result<Self, String> {
        match n {
            -1 => Ok(Trit::Yin),
            0 => Ok(Trit::Taiji),
            1 => Ok(Trit::Yang),
            _ => Err(format!("无效的极位值: {}", n)),
        }
    }
}

impl fmt::Display for Trit {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.to_char())
    }
}
